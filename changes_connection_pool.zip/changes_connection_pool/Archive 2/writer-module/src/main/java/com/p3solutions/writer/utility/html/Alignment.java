package com.p3solutions.writer.utility.html;


public enum Alignment {
    inherit,
    left,
    right;
}
