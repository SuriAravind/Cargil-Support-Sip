package com.p3solutions.writer.utility.others;

public interface IdentifiedEnum {
    
    int getId();
    
}
